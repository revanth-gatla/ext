#include<stdio.h>
#include<stdlib.h>

struct node {
    int data;
    struct node *left, *right;
};

struct node* insert(struct node *temp, int ele) {
    if(temp == NULL) {
        struct node *nn = (struct node *)malloc(sizeof(struct node));
        nn->data = ele;
        nn->left = nn->right = NULL;
        return nn;
    }
    if(ele > temp->data) {
        temp->right = insert(temp->right, ele);
    } else if(ele < temp->data) {
        temp->left = insert(temp->left, ele);
    }
    return temp;
}

void inorder(struct node *temp) {
    if(temp == NULL) return;
    inorder(temp->left);
    printf("%3d", temp->data);
    inorder(temp->right);
}

struct node* search(struct node *temp, int ele) {
    if(temp == NULL || temp->data == ele) return temp;
    if(ele < temp->data) return search(temp->left, ele);
    return search(temp->right, ele);
}

struct node* findMin(struct node* temp) {
    while (temp != NULL && temp->left != NULL) {
        temp = temp->left;
    }
    return temp;
}

struct node* deleteNode(struct node* temp, int data) {
    if (temp == NULL) return NULL;

    if (data < temp->data) {
        temp->left = deleteNode(temp->left, data);
    } else if (data > temp->data) {
        temp->right = deleteNode(temp->right, data);
    } else {
        if (temp->left == NULL && temp->right == NULL) {
            free(temp);
            return NULL;
        } else if (temp->left == NULL) {
            struct node *p = temp->right;
            free(temp);
            return p;
        } else if (temp->right == NULL) {
            struct node *p = temp->left;
            free(temp);
            return p;
        } else {
            struct node *p = findMin(temp->right);
            temp->data = p->data;
            temp->right = deleteNode(temp->right, p->data);
        }
    }
    return temp;
}

void main() {
    struct node *root = NULL;
    int choice, ele;
    while(1) {
        printf("\nMenu\n1.insert\n2.inorder traversal\n3.search\n4.delete\n5.exit\n");
        printf("Enter your choice\n");
        scanf("%d", &choice);
        switch(choice) {
            case 1: 
                printf("Enter element\n");
                scanf("%d", &ele);
                root = insert(root, ele);
                break;
            case 2: 
                if (root == NULL) printf("Empty Binary Search Tree");
                else { printf("Inorder traversal is:"); inorder(root); }
                break;
            case 3: 
                printf("Enter element to search\n");
                scanf("%d", &ele);
                if(search(root, ele) == NULL) printf("Element not found\n");
                else printf("Element found\n");
                break;
            case 4: 
                printf("Enter element to delete\n");
                scanf("%d", &ele);
                root = deleteNode(root, ele);
                break;
            case 5: exit(1);
        }
    }
}