#include<stdio.h>
#include<stdlib.h>

struct node {
    int data;
    struct node *left, *right;
};

struct node *que[25];
struct node *root = NULL, *curr;
int f = 0, r = -1;

struct node* create() {
    int ele;
    printf("Enter element (to quit press -1)\n");
    scanf("%d", &ele);
    while(ele != -1) {
        struct node *ptr = (struct node *)malloc(sizeof(struct node));
        ptr->data = ele;
        ptr->left = ptr->right = NULL;
        
        if(root == NULL) {
            root = ptr;
            r = 0;
            que[r] = ptr;
        } else {
            curr = que[f];
            if(curr->left == NULL) {
                curr->left = ptr;
            } else {
                curr->right = ptr;
            }
            r = r + 1;
            que[r] = ptr; 
            
            if(curr->left != NULL && curr->right != NULL) {
                f++;
            }
        }
        printf("Enter element (to quit press -1)\n");
        scanf("%d", &ele);
    }
    return root;
}

void inorder(struct node *ptr) {
    if(ptr == NULL) return;
    inorder(ptr->left);
    printf("%3d", ptr->data);
    inorder(ptr->right);
}

void preorder(struct node *ptr) {
    if(ptr == NULL) return;
    printf("%3d", ptr->data);
    preorder(ptr->left);
    preorder(ptr->right);
}

void postorder(struct node *ptr) {
    if(ptr == NULL) return;
    postorder(ptr->left);
    postorder(ptr->right);
    printf("%3d", ptr->data);
}

void levelorder(struct node *temp) {
    int i = 0;
    struct node *temp1;
    while(i <= r) {
        temp1 = que[i];
        printf("%3d", temp1->data);
        i++;
    }
}

int main() {
    int choice;
    struct node *temp = NULL;
    while(1) {
        printf("\n1.Create 2. PreOrder 3. InOrder 4. Postorder 5. Level Order 6.Exit\n");
        printf("Enter Choice\n");
        scanf("%d", &choice);
        switch(choice) {
            case 1: temp = create(); break;
            case 2: 
                if(temp == NULL) printf("Binary Tree is Empty\n");
                else { printf("PreOrder Traversal is:"); preorder(temp); }
                break;
            case 3: 
                if(temp == NULL) printf("Binary Tree is Empty\n");
                else { printf("InOrder Traversal is:"); inorder(temp); }
                break;
            case 4: 
                if(temp == NULL) printf("Binary Tree is Empty\n");
                else { printf("Post Order Traversal is:"); postorder(temp); }
                break;
            case 5: 
                if(temp == NULL) printf("Binary Tree is Empty\n");
                else { printf("Level Order Traversal is:"); levelorder(temp); }
                break;
            case 6: exit(1);
        }
    }
    return 0;
}